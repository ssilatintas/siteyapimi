<?php 
include "baglanti.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Mysia Organik Gıda Web Site</title>
    <link rel="stylesheet" href="styles/style.css"/>
    
</head>

<body>
  
    <header class="header">
        <a href="loginpage.php" class="logo">
            <img src="mysia/images/5fc698fb11a0f.png" alt="logo" />
        </a>
        <nav class="navbar">
            <a href="#nn" class="active">Ana Sayfa </a>
            <a href="#mm">Hakkımızda </a>
            <a href="#aa">Ürünlerimiz </a>
            <a href="#bb">Yorumlar</a>
            <a href="#dd">İletişim</a>
            <a href="#ff">Blogs</a>

            <a href="kaydol.php">Kaydol</a>
            <a href="girisyap.php">Giriş Yap</a>
        </nav>
        <div class="buttons">
            <button>
                <i class="fas fa-search"></i>
            </button>
            <button>
                <i class="fas fa-shopping-cart"></i>
            </button>
            <button id="urun-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="search-form">
            <input 
            type="text" 
            class="search-input"
            id="search-box"
            placeholder="Burada Ara"
            />
            <i class="fas fa-search"></i>
        </div>
    </header>