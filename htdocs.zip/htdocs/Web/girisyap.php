<?php
session_start();

include "baglanti.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullanici_ad = $_POST["kullanici_ad"];
    $sifre = $_POST["sifre"];

    // Güvenlik için kullanıcı girişi verilerini temizleme
    $kullanici_ad = mysqli_real_escape_string($baglan, $kullanici_ad);
    $sifre = mysqli_real_escape_string($baglan, $sifre);

    $sorgu = "SELECT * FROM kullanici_tablosu WHERE kullanici_ad = '$kullanici_ad' AND sifre = '$sifre'";
    $sonuc = mysqli_query($baglan, $sorgu);

    if (mysqli_num_rows($sonuc) == 1) {
        // Giriş başarılı, kullanıcıyı ana sayfaya yönlendir
        $_SESSION["kullanici_ad"] = $kullanici_ad;
        header("Location: ana_sayfa.php");
    } else {
        // Giriş başarısız
        $hata_mesaji = "Geçersiz kullanıcı adı veya şifre";
    }
}

mysqli_close($baglan);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }

        h2 {
            color: #333333;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333333;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #cccccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #3498db;
            color: #ffffff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        p.error-message {
            color: #e74c3c;
            margin-top: 0;
        }
    </style>
</head>

<body>

    <!-- <header class="header">
   
        <nav class="navbar">
            <a href="#nn" class="active">Ana Sayfa </a>
            <a href="#mm">Hakkımızda </a>
            <a href="#aa">Ürünlerimiz </a>
            <a href="#bb">Yorumlar</a>
            <a href="#dd">İletişim</a>
            <a href="#ff">Blogs</a>

            <a href="kaydol.php">Kaydol</a>
            <a href="girisyap.php">Giriş Yap</a>
        </nav>
        <div class="buttons">
            <button>
                <i class="fas fa-search"></i>
            </button>
            <button>
                <i class="fas fa-shopping-cart"></i>
            </button>
            <button id="urun-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="search-form">
            <input type="text" class="search-input" id="search-box" placeholder="Burada Ara" />
            <i class="fas fa-search"></i>
        </div>
    </header> -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h2>Giriş Yap</h2>

        <?php if (isset($hata_mesaji)) { ?>
            <p class="error-message"><?php echo $hata_mesaji; ?></p>
        <?php } ?>

        <label for="kullanici_ad">Kullanıcı Adı:</label>
        <input type="text" name="kullanici_ad" required>

        <label for="sifre">Şifre:</label>
        <input type="password" name="sifre" required>

        <input type="submit" value="Giriş Yap">
    </form>
</body>

</html>