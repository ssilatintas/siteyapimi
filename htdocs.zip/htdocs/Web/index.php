<?php
include "baglanti.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Mysia Organik Gıda Web Site</title>
    <link rel="stylesheet" href="styles/style.css" />

</head>

<body>

    <header class="header">
        <a href="loginpage.php" class="logo">
            <img src="mysia/images/5fc698fb11a0f.png" alt="logo" />
        </a>
        <nav class="navbar">
            <a href="#nn" class="active">Ana Sayfa </a>
            <a href="#mm">Hakkımızda </a>
            <a href="#aa">Ürünlerimiz </a>
            <a href="#bb">Yorumlar</a>
            <a href="#dd">İletişim</a>
            <a href="#ff">Blogs</a>

        </nav>
        <div class="buttons">
            <button >
                <a style="color: black;" href="girisyap.php"><i class="fa-solid fa-user"></i></a>
            </button>
            <button>
                <a style="color: black;" href="kaydol.php"><i class="fa-solid fa-address-card"></i></a>
            </button>
            <button>
                <i class="fas fa-search"></i>
            </button>
            <button>
                <i class="fas fa-shopping-cart"></i>
            </button>
            <button id="urun-btn">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="search-form">
            <input type="text" class="search-input" id="search-box" placeholder="Burada Ara" />
            <i class="fas fa-search"></i>
        </div>
    </header>



    <section id="nn" class="home">
        <div class="content">
            <h3>HIZLI TESLİMAT</h3>
            <p>
                Sağlığınıza ve çevreye duyarlı bir yaşam tarzını benimseyenler için, organik gıdaların gücü hiçbir zaman küçümsenemez.
                Organik gıdalarımız, toprak dostu yöntemlerle yetiştirilir ve zararlı kimyasallar içermez.
                Sitemizde, organik ürünlerin geniş bir yelpazesini sunuyoruz; bu ürünler tazelik, lezzet ve besin değeri açısından zirvede.
                İşte sizin ve ailenizin sağlığına katkı sağlayacak organik gıdaları keşfetmek için doğru yerdesiniz.
                Doğadan sofranıza en taze ve sağlıklı organik ürünleri sunmak için çalışıyoruz. Sitemizi ziyaret edin ve organik gıdaların benzersiz tadını çıkarın.
            </p>
            <a href="#" class="btn">Şimdi Satın Al </a>
        </div>
    </section>

    <section id="aa" class="urunlerimiz">
        <h1>Ürünlerimiz</h1>
        <div class="box-container">
            <?php
            $sql = "SELECT * FROM urunler";
            $result = $baglan->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo '<div class="box">
            <div class="box-head">
            <img src="mysia/images/' . $row["urun_resim"] . '" alt="Ürünlerimiz" />
                <h3>' . $row["urun_baslik"] . '</h3>
                <div class="price">' . $row["urun_kg"] . '
                <del>' . $row["urun_efiyat"] . 'TL</del> <span>' . $row["urun_yfiyat"] . 'TL</span>
                </div>
            </div>
            <div class="box-bottom">
                <a href="#" class="btn">Sepete Ekle</a>
            </div>
        </div>';
            }

            // Veritabanı bağlantısını kapat
            ?>

        </div>

    </section>
    <!--! about section start -->
    <!-- <section id="mm" class="hakkımızda">
    <h1 class="heading">Hakkımızda </h1>
    <div class="row">
        <div class="image">
            <img src="mysia/images/odulyeni.jpg" alt="hakkımızda" />
        </div>
        <div class="content">
            <h3>Ödüllü Zeytinyağı Üreticisi Olarak Tanıyalım</h3>
            <p>2013 yılında yola çıkan firmamız, sağlıklı ve organik beslenme konusundaki tutkumuzu sizinle paylaşmak için burada. Amacımız, sofralarınıza en kaliteli ve doğal ürünleri ulaştırmak, sağlıklı bir yaşam tarzına olan bağlılığınızı desteklemek.
            <p>Organik tarımın gücüne inanıyoruz. Toprağa, bitkiye ve insana saygı duyan bu özel yöntemle yetiştirdiğimiz ürünlerimiz, sofralarınıza doğanın bize sunduğu en iyiyi getiriyor. Sağlıklı beslenme ve sürdürülebilir tarım ilkelerini benimseyerek, gelecek nesillere temiz ve sağlıklı bir dünya bırakmayı hedefliyoruz.
                Bu yolculukta sizinle birlikte olmak istiyoruz. Organik gıda ile tanışmanızı sağlamak, şeffaf ve güvenilir bir ticaret anlayışıyla hareket etmek, bize duyduğunuz güvenin karşılığını en kaliteli ürünlerle vermek için buradayız. Gıdamızı, tarladan sofranıza uzanan bu özel serüvenimizde bizimle paylaşın.</p>
            <h2>Sizlere Teşekkür Ediyoruz...</h2>
            <p>Bizler, bu serüvenin bir parçası olmanın heyecanını yaşıyoruz. Her bir müşterimizle, doğadan soframıza uzanan bu yolda birlikte büyüyoruz. Bize duyduğunuz güven ve tercihiniz için teşekkür ederiz. Sağlıklı ve lezzetli bir gelecek için birlikte daha nice yıllara!</p>
            <h3>MYSIA OLİVE-GÜLŞAH ACEMLİLER</h3>
            <a href="#" class="btn">Daha Fazlasını Gör</a>
        </div>
    </div>
</section> -->

    <?php
    // Veritabanı bağlantınızı sağladığınızdan emin olun

    // Veritabanından "hakkimizda" tablosundaki verileri çek
    $sql = "SELECT * FROM hakkimizda";
    $result = $baglan->query($sql);

    // Verileri çekerek HTML bloğunu oluştur
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<section id="mm" class="hakkımızda">
                <h1 class="heading">Hakkımızda</h1>
                <div class="row">
                    <div class="image">
                        <img src="mysia/images/' . $row["hakkimizda_resim"] . '" alt="hakkımızda" />
                    </div>
                    <div class="content">
                        <h3>' . $row["hakkimizda_baslik"] . '</h3>
                        <p>' . $row["hakkimizda_yazi"] . '</p>
                        <h2>Sizlere Teşekkür Ediyoruz...</h2>
                        <p>Bizler, bu serüvenin bir parçası olmanın heyecanını yaşıyoruz. Her bir müşterimizle, doğadan soframıza uzanan bu yolda birlikte büyüyoruz. Bize duyduğunuz güven ve tercihiniz için teşekkür ederiz. Sağlıklı ve lezzetli bir gelecek için birlikte daha nice yıllara!</p>
                        <h3>MYSIA OLİVE-GÜLŞAH ACEMLİLER</h3>
                        <a href="#" class="btn">Daha Fazlasını Gör</a>
                    </div>
                </div>
            </section>';
        }
    } else {
        echo "Veritabanında hakkında bilgisi bulunamadı.";
    }
    ?>

    <!--! about section end -->
    <!--! review start -->
    <section id="bb" class="yorumlar">
        <h1 class="heading">Müşterilerin Yorumları</h1>
        <div class="box-container">
            <div class="box">
                <img src="mysia/images/quote.png" alt="alıntı" />
                <p>"Ürünlerinizin sertifikalı organik olması beni güvende hissettiriyor. Sağlığım için bu kadar kaliteli seçeneklere ulaşabilmek harika!"</p>
                <img src="mysia/images/avatar-1.png" alt="avatar" class="user" />
                <h3>Zeynep Yılmaz</h3>
                <div class="starts">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
            </div>

            <?php

            // Yorumları veritabanından çek
            $sql = "SELECT * FROM iletisim";
            $result = $baglan->query($sql);

            // Yorumları HTML içinde görüntüle
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="box">
                <img src="mysia/images/quote.png" alt="alıntı" />
                <p>"' . $row["mesaj"] . '"</p>
                <img src="mysia/images/avatar-1.png" alt="avatar" class="user" />
                <h3>' . $row["isimsoyisim"] . '</h3>
    
                    <div class="starts">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i></div>
                    </div>';
                }
            } else {
                echo "Veritabanında yorum bulunamadı.";
            }

            ?>
        </div>
    </section>
    <!--! review end -->
    <!--! iletisim start -->
    <section id="dd" class="iletisim">
        <h1 class="heading">İletişim</h1>
        <div class="row">
            <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3040.4712910449625!2d27.97193825115428!3d40.354073156658686!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14b5d3a76b677149%3A0x93d46d431285b354!2zR8O8bmF5ZMSxbiwgUGF6YXIgQ2QuIE5vOjE2LCAxMDIwMCBCYW5kxLFybWEvQmFsxLFrZXNpcg!5e0!3m2!1str!2str!4v1700080824402!5m2!1str!2str" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <form action="index.php" method="post">
                <h3>Bize Ulaş</h3>
                <div class="inputBox">
                    <i class="fas fa-user"></i>
                    <input type="text" name="isimsoyisim" placeholder="isimsoyisim" />
                </div>
                <div class="inputBox">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email" />
                </div>
                <div class="inputBox">
                    <i class="fas fa-phone"></i>
                    <input type="telefon" name="telefon" placeholder="Tel No" />
                </div>
                <div class="inputBox">
                    <i class="fas fa-comment"></i>
                    <textarea name="mesaj" style="width: 600px; background-color:#0f0d0d; color:white;" placeholder="Mesajınızı Giriniz" name="" id="" cols="30" rows="10"></textarea>
                </div>
                <input type="submit" class="btn" value="Şimdi İletişime Geç" />
            </form>
        </div>
    </section>
    <!--! iletisim end -->
    <!--! blogs start -->
    <section id="ff" class="blogs">
        <h1 class="heading">blog</h1>
        <div class="box-container">
            <!-- <div class="box">
            <div class="image">
                <img src="mysia/images/zeytinyagi-.jpg" alt="blog">
            </div>
            <div class="content">
                <a href="#" class="title"> Organik Zeytinyağı: Kalbinize İyi Gelen Yağlar</a>
                <span>by admin/16 ekim 2023</span>
                <p>Organik zeytinyağı, doğal olarak üretilen ve kimyasal işlemlerden arındırılan bir yağ türüdür. Bu değerli yağ, yüksek antioksidan içeriği sayesinde kalp sağlığını destekler. Aynı zamanda, sağlıklı yağ asitleri bakımından zengin olmasıyla bilinir. </p>
                <a href="#" class="btn">Daha Fazla Oku</a>
            </div>

        </div> -->

            <?php

            // Blog verilerini çek
            $sql = "SELECT * FROM blog";
            $result = $baglan->query($sql);

            // Blogları HTML içinde görüntüle
            if ($result->num_rows > 0) {
                while ($blog = $result->fetch_assoc()) {
                    echo '<div class="box">
                <div class="image">
                    <img src="mysia/images/' . $blog['blog_resim'] . '" alt="blog">
                </div>
                <div class="content">
                    <a href="#" class="title">' . $blog['blog_baslik'] . '</a>
                    <span>by ' . $blog['blog_yazar'] . '/' . $blog['blog_tarih'] . '</span>
                    <p>' . $blog['blog_yazi'] . '</p>
                    <a href="#" class="btn">Daha Fazla Oku</a>
                </div>
            </div>';
                }
            } else {
                echo "Veritabanında blog verisi bulunamadı.";
            }

            // Bağlantıyı kapat
            $baglan->close();
            ?>


        </div>
    </section>
    <!--! blogs  end -->
    <!--! footer start -->

    <!--! footer end -->
    <section class="footer">
        <div class="search">
            <input type="text" class="search-input" placeholder="Ara" />
            <button class="btn btn-primary">Ara</button>
        </div>
        <div class="share">
            <a href="#" class="fab fa-facebook"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-whatsapp"></a>
        </div>
        <div class="links">
            <a href="#" class="active">Ana Sayfa </a>
            <a href="#">Hakkımızda </a>
            <a href="#">Ürünlerimiz </a>
            <a href="#">Yorumlar</a>
            <a href="#">İletişim</a>
            <a href="#">Blogs</a>
        </div>
        <div class="credit">
            created by <span>Sıla Tintaş</span> | all rights reserved
        </div>
    </section>
</body>

</html>



<?php

include("baglanti.php");

if (isset($_POST["isimsoyisim"], $_POST["email"], $_POST["telefon"], $_POST["mesaj"])) {
    $isimsoyisim = $_POST["isimsoyisim"];
    $email = $_POST["email"];
    $telefon = $_POST["telefon"];
    $mesaj = $_POST["mesaj"];

    $stmt = $baglan->prepare("INSERT INTO iletisim (isimsoyisim, email, telefon, mesaj) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $isimsoyisim, $email, $telefon, $mesaj);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Mesajınız Başarı İle Gönderilmiştir.')</script>";
    } else {
        echo "Hata: " . $stmt->error;
    }

}

?>