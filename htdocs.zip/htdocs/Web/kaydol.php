<?php
// Yukarıdaki bağlantı kodunu ekleyin
session_start();
include "baglanti.php";



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Formdan gelen verileri alın
    $kullanici_adi = $_POST["kullanici_adi"];
    $email = $_POST["email"];
    $sifre = $_POST["sifre"];

    // Veritabanına kullanıcıyı ekleme
    $sifre_hash = password_hash($sifre, PASSWORD_DEFAULT); // Şifreyi güvenli bir şekilde hashleme
    $kayit_tarih = date("Y-m-d H:i:s");

    $ekle_sorgusu = "INSERT INTO kullanici_tablosu (kullanici_ad, email, sifre) VALUES ('$kullanici_adi', '$email', '$sifre_hash')";

    if (mysqli_query($baglan, $ekle_sorgusu)) {
      header('Location:anp.php');
    } else {
        echo "Hata: " . $ekle_sorgusu . "<br>" . mysqli_error($baglan);
    }
}

mysqli_close($baglan);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kaydol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h2 {
            text-align: center;
            color: #333333;
        }

        input {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #ffffff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>


    <form method="post" action="kaydol.php">
        <h2>Kaydol</h2>
        <input type="text" name="kullanici_adi" placeholder="Kullanıcı Adı" required>
        <input type="email" name="email" placeholder="E-posta" required>
        <input type="password" name="sifre" placeholder="Şifre" required>
        <input type="submit" value="Kaydol">
    </form>
</body>

</html>